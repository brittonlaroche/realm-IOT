import { Edgelist } from "../containers/edges";
export const Edges = (props) => {
  return <Edgelist edges={props.edges} />;
};
