#!/bin/bash
set -x #echo on
docker network create realm-aedes-net