# MQTT Clients

Simple client to pull in data from sense hat and push it to the aedes broker
